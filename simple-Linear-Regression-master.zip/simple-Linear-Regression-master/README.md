# simple-Linear-Regression
Simple Linear implementation with python
